import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar: string;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  logout: () => void;
  isLoading: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check for existing user session
    const userData = localStorage.getItem('netflix_user');
    if (userData) {
      setUser(JSON.parse(userData));
    }
    setIsLoading(false);
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // Check if user exists in localStorage
      const existingUsers = JSON.parse(localStorage.getItem('netflix_users') || '[]');
      const userExists = existingUsers.find((u: any) => u.email === email && u.password === password);
      
      if (userExists) {
        const userData = {
          id: userExists.id,
          email: userExists.email,
          name: userExists.name,
          avatar: `https://ui-avatars.com/api/?name=${userExists.name}&background=e50914&color=fff`
        };
        setUser(userData);
        localStorage.setItem('netflix_user', JSON.stringify(userData));
        return true;
      }
      return false;
    } catch (error) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (email: string, password: string, name: string): Promise<boolean> => {
    setIsLoading(true);
    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      const existingUsers = JSON.parse(localStorage.getItem('netflix_users') || '[]');
      const userExists = existingUsers.find((u: any) => u.email === email);
      
      if (userExists) {
        return false; // User already exists
      }
      
      const newUser = {
        id: Date.now().toString(),
        email,
        password,
        name
      };
      
      existingUsers.push(newUser);
      localStorage.setItem('netflix_users', JSON.stringify(existingUsers));
      
      const userData = {
        id: newUser.id,
        email: newUser.email,
        name: newUser.name,
        avatar: `https://ui-avatars.com/api/?name=${newUser.name}&background=e50914&color=fff`
      };
      
      setUser(userData);
      localStorage.setItem('netflix_user', JSON.stringify(userData));
      return true;
    } catch (error) {
      return false;
    } finally {
      setIsLoading(false);
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('netflix_user');
  };

  return (
    <AuthContext.Provider value={{ user, login, signup, logout, isLoading }}>
      {children}
    </AuthContext.Provider>
  );
};