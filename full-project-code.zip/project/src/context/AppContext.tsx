import React, { createContext, useContext, useState, useEffect } from 'react';
import { Movie } from '../data/movies';

interface AppContextType {
  myList: Movie[];
  addToMyList: (movie: Movie) => void;
  removeFromMyList: (movieId: string) => void;
  isInMyList: (movieId: string) => boolean;
  recentlyWatched: Movie[];
  addToRecentlyWatched: (movie: Movie) => void;
  selectedMovie: Movie | null;
  setSelectedMovie: (movie: Movie | null) => void;
  showTrailer: boolean;
  setShowTrailer: (show: boolean) => void;
  currentView: 'home' | 'tv-shows' | 'movies' | 'my-list';
  setCurrentView: (view: 'home' | 'tv-shows' | 'movies' | 'my-list') => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [myList, setMyList] = useState<Movie[]>([]);
  const [recentlyWatched, setRecentlyWatched] = useState<Movie[]>([]);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'tv-shows' | 'movies' | 'my-list'>('home');

  useEffect(() => {
    // Load saved data from localStorage
    const savedMyList = localStorage.getItem('netflix_mylist');
    const savedRecentlyWatched = localStorage.getItem('netflix_recently_watched');
    
    if (savedMyList) {
      setMyList(JSON.parse(savedMyList));
    }
    
    if (savedRecentlyWatched) {
      setRecentlyWatched(JSON.parse(savedRecentlyWatched));
    }
  }, []);

  const addToMyList = (movie: Movie) => {
    const updatedList = [...myList, movie];
    setMyList(updatedList);
    localStorage.setItem('netflix_mylist', JSON.stringify(updatedList));
  };

  const removeFromMyList = (movieId: string) => {
    const updatedList = myList.filter(movie => movie.id !== movieId);
    setMyList(updatedList);
    localStorage.setItem('netflix_mylist', JSON.stringify(updatedList));
  };

  const isInMyList = (movieId: string) => {
    return myList.some(movie => movie.id === movieId);
  };

  const addToRecentlyWatched = (movie: Movie) => {
    const updatedList = [movie, ...recentlyWatched.filter(m => m.id !== movie.id)].slice(0, 10);
    setRecentlyWatched(updatedList);
    localStorage.setItem('netflix_recently_watched', JSON.stringify(updatedList));
  };

  return (
    <AppContext.Provider value={{
      myList,
      addToMyList,
      removeFromMyList,
      isInMyList,
      recentlyWatched,
      addToRecentlyWatched,
      selectedMovie,
      setSelectedMovie,
      showTrailer,
      setShowTrailer,
      currentView,
      setCurrentView
    }}>
      {children}
    </AppContext.Provider>
  );
};