import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider } from './context/AppContext';
import AuthPage from './components/Auth/AuthPage';
import Navbar from './components/Navbar/Navbar';
import Home from './components/Home/Home';
import TVShows from './components/TVShows/TVShows';
import Movies from './components/Movies/Movies';
import MyList from './components/MyList/MyList';
import MovieModal from './components/MovieModal/MovieModal';
import { useApp } from './context/AppContext';

const AppContent: React.FC = () => {
  const { user, isLoading } = useAuth();
  const { currentView } = useApp();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="text-white text-2xl">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  const renderCurrentView = () => {
    switch (currentView) {
      case 'tv-shows':
        return <TVShows />;
      case 'movies':
        return <Movies />;
      case 'my-list':
        return <MyList />;
      default:
        return <Home />;
    }
  };

  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      {renderCurrentView()}
      <MovieModal />
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <AppProvider>
        <AppContent />
      </AppProvider>
    </AuthProvider>
  );
};

export default App;