import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Eye, EyeOff, Mail, Lock, User, CheckCircle } from 'lucide-react';

const AuthPage: React.FC = () => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showEmailVerification, setShowEmailVerification] = useState(false);
  const { login, signup, isLoading } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isSignUp) {
      if (!name.trim()) {
        setError('Name is required');
        return;
      }
      const success = await signup(email, password, name);
      if (success) {
        setShowEmailVerification(true);
        setTimeout(() => {
          setShowEmailVerification(false);
        }, 3000);
      } else {
        setError('User already exists with this email');
      }
    } else {
      const success = await login(email, password);
      if (!success) {
        setError('Invalid email or password');
      }
    }
  };

  if (showEmailVerification) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden px-4">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Netflix Background"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-70"></div>
        </div>

        <div className="relative z-10 bg-black bg-opacity-90 backdrop-blur-sm p-8 sm:p-12 lg:p-16 rounded-2xl w-full max-w-md mx-4 text-center border border-green-500 border-opacity-30">
          <div className="mb-6">
            <CheckCircle className="text-green-400 mx-auto mb-4" size={48} className="sm:w-16 sm:h-16" />
            <h2 className="text-white text-2xl sm:text-3xl font-bold mb-4">Email Verified!</h2>
            <p className="text-gray-300 text-sm sm:text-base">Welcome to Netflix! You can now enjoy unlimited streaming.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black flex items-center justify-center relative overflow-hidden px-4">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <img 
          src="https://images.pexels.com/photos/7991579/pexels-photo-7991579.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Netflix Background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-black bg-opacity-70"></div>
      </div>

      {/* Netflix Logo */}
      <div className="absolute top-4 sm:top-8 left-4 sm:left-8 z-10">
        <h1 className="text-red-600 text-3xl sm:text-4xl lg:text-5xl font-black">NETFLIX</h1>
      </div>

      {/* Auth Form */}
      <div className="relative z-10 bg-black bg-opacity-90 backdrop-blur-sm p-8 sm:p-12 lg:p-16 rounded-2xl w-full max-w-md mx-4 shadow-2xl border border-gray-800">
        <h2 className="text-white text-3xl sm:text-4xl font-bold mb-6 sm:mb-8 text-center">
          {isSignUp ? 'Sign Up' : 'Sign In'}
        </h2>

        {error && (
          <div className="bg-red-600 bg-opacity-90 text-white p-3 sm:p-4 rounded-lg mb-4 sm:mb-6 text-sm font-semibold flex items-center space-x-2">
            <span>⚠️</span>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-6">
          {isSignUp && (
            <div className="relative">
              <User className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} className="sm:w-5 sm:h-5" />
              <input
                type="text"
                placeholder="Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 sm:pl-12 pr-3 sm:pr-4 py-3 sm:py-4 bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white rounded-lg border border-gray-600 focus:border-red-500 focus:outline-none transition-all duration-300 placeholder-gray-400 text-sm sm:text-base"
                required
              />
            </div>
          )}

          <div className="relative">
            <Mail className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} className="sm:w-5 sm:h-5" />
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full pl-10 sm:pl-12 pr-3 sm:pr-4 py-3 sm:py-4 bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white rounded-lg border border-gray-600 focus:border-red-500 focus:outline-none transition-all duration-300 placeholder-gray-400 text-sm sm:text-base"
              required
            />
          </div>

          <div className="relative">
            <Lock className="absolute left-3 sm:left-4 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} className="sm:w-5 sm:h-5" />
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full pl-10 sm:pl-12 pr-10 sm:pr-12 py-3 sm:py-4 bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white rounded-lg border border-gray-600 focus:border-red-500 focus:outline-none transition-all duration-300 placeholder-gray-400 text-sm sm:text-base"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 sm:right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-white transition-colors"
            >
              {showPassword ? <EyeOff size={18} className="sm:w-5 sm:h-5" /> : <Eye size={18} className="sm:w-5 sm:h-5" />}
            </button>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-red-600 to-red-700 text-white py-3 sm:py-4 rounded-lg font-bold text-base sm:text-lg hover:from-red-700 hover:to-red-800 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-105 shadow-2xl"
          >
            {isLoading ? (
              <div className="flex items-center justify-center space-x-2">
                <div className="loading-spinner w-4 h-4 sm:w-5 sm:h-5"></div>
                <span>Loading...</span>
              </div>
            ) : (
              isSignUp ? 'Sign Up' : 'Sign In'
            )}
          </button>
        </form>

        <div className="mt-6 sm:mt-8 text-center">
          {isSignUp ? (
            <p className="text-gray-400 text-sm sm:text-base">
              Already have an account?{' '}
              <button
                onClick={() => setIsSignUp(false)}
                className="text-white hover:text-red-400 transition-colors font-semibold ml-1"
              >
                Sign in now
              </button>
            </p>
          ) : (
            <p className="text-gray-400 text-sm sm:text-base">
              New to Netflix?{' '}
              <button
                onClick={() => setIsSignUp(true)}
                className="text-white hover:text-red-400 transition-colors font-semibold ml-1"
              >
                Sign up now
              </button>
            </p>
          )}
        </div>

        <div className="mt-6 sm:mt-8 text-center text-xs text-gray-500">
          <p>This page is protected by Google reCAPTCHA to ensure you're not a bot.</p>
        </div>
      </div>
    </div>
  );
};

export default AuthPage;