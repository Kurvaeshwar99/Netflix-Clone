import React, { useEffect } from 'react';
import { X, Play, Plus, Check, ThumbsUp, Volume2, Star, Award, Globe, Calendar } from 'lucide-react';
import { useApp } from '../../context/AppContext';

const MovieModal: React.FC = () => {
  const { 
    selectedMovie, 
    setSelectedMovie, 
    showTrailer, 
    setShowTrailer, 
    addToMyList, 
    removeFromMyList, 
    isInMyList,
    addToRecentlyWatched 
  } = useApp();

  useEffect(() => {
    if (showTrailer && selectedMovie) {
      // Add to recently watched when trailer is played
      addToRecentlyWatched(selectedMovie);
    }
  }, [showTrailer, selectedMovie, addToRecentlyWatched]);

  const handleClose = () => {
    setShowTrailer(false);
    setSelectedMovie(null);
  };

  const handleMyList = () => {
    if (selectedMovie) {
      if (isInMyList(selectedMovie.id)) {
        removeFromMyList(selectedMovie.id);
      } else {
        addToMyList(selectedMovie);
      }
    }
  };

  if (!showTrailer || !selectedMovie) return null;

  const inMyList = isInMyList(selectedMovie.id);

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 z-50 flex items-center justify-center p-2 sm:p-4 modal-enter">
      <div className="bg-gray-900 rounded-xl max-w-6xl w-full max-h-[95vh] overflow-y-auto shadow-2xl">
        {/* Close Button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 sm:top-6 sm:right-6 z-10 bg-black bg-opacity-70 text-white p-2 sm:p-3 rounded-full hover:bg-opacity-90 transition-all duration-300 hover:scale-110"
        >
          <X size={20} className="sm:w-6 sm:h-6" />
        </button>

        {/* Video Player Section */}
        <div className="relative w-full h-64 sm:h-80 lg:h-96 bg-gradient-to-r from-gray-900 to-gray-800 rounded-t-xl overflow-hidden">
          <img
            src={selectedMovie.backdrop}
            alt={selectedMovie.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent"></div>
          
          {/* Play Button Overlay */}
          <div className="absolute inset-0 flex items-center justify-center">
            <button className="bg-white bg-opacity-20 backdrop-blur-sm text-white p-4 sm:p-6 rounded-full hover:bg-opacity-30 transition-all duration-300 hover:scale-110 shadow-2xl">
              <Play size={32} className="sm:w-12 sm:h-12" fill="white" />
            </button>
          </div>
          
          {/* Video Controls */}
          <div className="absolute bottom-4 sm:bottom-6 left-4 sm:left-6 right-4 sm:right-6 flex items-center justify-between">
            <div className="flex items-center space-x-2 sm:space-x-4">
              <button
                onClick={handleClose}
                className="flex items-center space-x-2 sm:space-x-3 bg-white text-black px-4 py-2 sm:px-6 sm:py-3 lg:px-8 lg:py-3 rounded-lg font-bold text-sm sm:text-base lg:text-lg hover:bg-gray-200 transition-all duration-300 hover:scale-105 shadow-lg"
              >
                <Play size={16} className="sm:w-5 sm:h-5" fill="black" />
                <span>Play</span>
              </button>
              <button
                onClick={handleMyList}
                className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg"
              >
                {inMyList ? <Check size={20} className="sm:w-6 sm:h-6" /> : <Plus size={20} className="sm:w-6 sm:h-6" />}
              </button>
              <button className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg">
                <ThumbsUp size={20} className="sm:w-6 sm:h-6" />
              </button>
            </div>
            <button className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg">
              <Volume2 size={20} className="sm:w-6 sm:h-6" />
            </button>
          </div>
        </div>

        {/* Movie Details */}
        <div className="p-4 sm:p-6 lg:p-8 bg-gradient-to-b from-gray-900 to-black">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* Main Info */}
            <div className="lg:col-span-2 space-y-4 sm:space-y-6">
              <div className="flex items-start justify-between mb-4 sm:mb-6">
                <div className="flex-1">
                  <h2 className="text-white text-2xl sm:text-3xl lg:text-4xl font-bold mb-3 text-shadow">{selectedMovie.title}</h2>
                  <div className="flex flex-wrap items-center gap-3 sm:gap-4 lg:gap-6 text-base sm:text-lg text-gray-300 mb-4">
                    <div className="flex items-center space-x-2">
                      <Star className="text-yellow-400" size={16} className="sm:w-5 sm:h-5" fill="currentColor" />
                      <span className="text-yellow-400 font-bold">
                        {selectedMovie.rating}/10
                      </span>
                    </div>
                    <span className="text-green-400 font-bold">
                      {Math.round(selectedMovie.rating * 10)}% Match
                    </span>
                    <span className="border border-gray-400 px-2 py-1 sm:px-3 sm:py-1 text-xs sm:text-sm rounded">
                      {selectedMovie.maturityRating}
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-gray-300 text-base sm:text-lg leading-relaxed mb-6 sm:mb-8 text-shadow">
                {selectedMovie.description}
              </p>

              {/* Cast & Crew */}
              <div className="space-y-3 sm:space-y-4 mb-6 sm:mb-8">
                {selectedMovie.director && (
                  <div className="flex flex-col sm:flex-row sm:items-start space-y-1 sm:space-y-0 sm:space-x-4">
                    <span className="text-gray-400 font-semibold min-w-[100px]">Director:</span>
                    <span className="text-white">{selectedMovie.director}</span>
                  </div>
                )}
                {selectedMovie.cast && (
                  <div className="flex flex-col sm:flex-row sm:items-start space-y-1 sm:space-y-0 sm:space-x-4">
                    <span className="text-gray-400 font-semibold min-w-[100px]">Cast:</span>
                    <span className="text-white">{selectedMovie.cast.join(', ')}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Sidebar Info */}
            <div className="space-y-4 sm:space-y-6">
              {/* Movie Poster */}
              <div className="relative group">
                <img
                  src={selectedMovie.poster}
                  alt={selectedMovie.title}
                  className="w-full rounded-lg shadow-2xl transition-transform duration-300 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-20 transition-opacity duration-300 rounded-lg"></div>
              </div>

              {/* Movie Stats */}
              <div className="bg-gray-800 bg-opacity-50 backdrop-blur-sm rounded-lg p-4 sm:p-6 space-y-3 sm:space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Year</span>
                  <div className="flex items-center space-x-2">
                    <Calendar size={14} className="sm:w-4 sm:h-4 text-gray-400" />
                    <span className="text-white font-semibold">{selectedMovie.year}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Duration</span>
                  <span className="text-white font-semibold">{selectedMovie.duration}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Language</span>
                  <div className="flex items-center space-x-2">
                    <Globe size={14} className="sm:w-4 sm:h-4 text-gray-400" />
                    <span className="text-white font-semibold">{selectedMovie.language}</span>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Country</span>
                  <span className="text-white font-semibold">{selectedMovie.country}</span>
                </div>
              </div>

              {/* Awards */}
              {selectedMovie.awards && (
                <div className="bg-gradient-to-r from-yellow-900 to-yellow-800 bg-opacity-30 backdrop-blur-sm rounded-lg p-4 sm:p-6">
                  <div className="flex items-center space-x-3 mb-3">
                    <Award className="text-yellow-400" size={20} className="sm:w-6 sm:h-6" />
                    <h3 className="text-white font-bold text-base sm:text-lg">Awards</h3>
                  </div>
                  <p className="text-yellow-200 text-sm sm:text-base">{selectedMovie.awards}</p>
                </div>
              )}

              {/* Genres */}
              <div>
                <h3 className="text-white font-bold text-base sm:text-lg mb-3 sm:mb-4">Genres</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedMovie.genre.map((genre, index) => (
                    <span 
                      key={index} 
                      className="bg-red-600 bg-opacity-80 text-white px-3 py-1 sm:px-4 sm:py-2 rounded-full text-xs sm:text-sm font-semibold hover:bg-opacity-100 transition-all duration-300 cursor-pointer"
                    >
                      {genre}
                    </span>
                  ))}
                </div>
              </div>

              {/* Platform Info */}
              <div className="bg-red-600 bg-opacity-20 backdrop-blur-sm rounded-lg p-4 sm:p-6 border border-red-600 border-opacity-30">
                <h3 className="text-white font-bold text-base sm:text-lg mb-3">Available On</h3>
                <div className="flex flex-wrap items-center gap-3">
                  <span className="bg-red-600 text-white px-3 py-1 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-bold shadow-lg">
                    NETFLIX
                  </span>
                  {selectedMovie.isNetflixOriginal && (
                    <span className="bg-gray-800 text-gray-300 px-3 py-1 sm:px-4 sm:py-2 rounded-lg text-xs sm:text-sm font-semibold">
                      ORIGINAL
                    </span>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MovieModal;