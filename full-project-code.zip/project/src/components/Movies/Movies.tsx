import React from 'react';
import MovieRow from '../MovieRow/MovieRow';
import { 
  movies, 
  actionMovies, 
  comedyMovies, 
  dramaMovies, 
  horrorMovies, 
  topRatedMovies 
} from '../../data/movies';

const Movies: React.FC = () => {
  return (
    <div className="bg-black min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-white text-4xl font-bold mb-8">Movies</h1>
        
        <div className="space-y-8">
          <MovieRow title="All Movies" movies={movies} />
          <MovieRow title="Top Rated" movies={topRatedMovies} />
          <MovieRow title="Action & Adventure" movies={actionMovies} />
          <MovieRow title="Comedy" movies={comedyMovies} />
          <MovieRow title="Drama" movies={dramaMovies} />
          <MovieRow title="Horror & Thriller" movies={horrorMovies} />
        </div>
      </div>
    </div>
  );
};

export default Movies;