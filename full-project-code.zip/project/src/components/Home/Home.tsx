import React from 'react';
import Hero from '../Hero/Hero';
import MovieRow from '../MovieRow/MovieRow';
import { 
  movies, 
  top10Movies, 
  trendingMovies, 
  netflixOriginals, 
  actionMovies, 
  comedyMovies, 
  dramaMovies, 
  horrorMovies 
} from '../../data/movies';
import { useApp } from '../../context/AppContext';

const Home: React.FC = () => {
  const { recentlyWatched } = useApp();

  return (
    <div className="bg-black min-h-screen">
      <Hero />
      
      <div className="relative z-10 -mt-32 space-y-8">
        {/* Top 10 Movies in Netflix Today */}
        <MovieRow title="Top 10 Movies in Netflix Today" movies={top10Movies} isTop10 />
        
        {/* Recently Watched */}
        {recentlyWatched.length > 0 && (
          <MovieRow title="Continue Watching" movies={recentlyWatched} />
        )}
        
        {/* Trending Now */}
        <MovieRow title="Trending Now" movies={trendingMovies} />
        
        {/* Netflix Originals */}
        <MovieRow title="Netflix Originals" movies={netflixOriginals} />
        
        {/* Action Movies */}
        <MovieRow title="Action & Adventure" movies={actionMovies} />
        
        {/* Comedy Movies */}
        <MovieRow title="Comedy Movies" movies={comedyMovies} />
        
        {/* Drama Movies */}
        <MovieRow title="Drama Movies" movies={dramaMovies} />
        
        {/* Horror Movies */}
        <MovieRow title="Horror Movies" movies={horrorMovies} />
      </div>
    </div>
  );
};

export default Home;