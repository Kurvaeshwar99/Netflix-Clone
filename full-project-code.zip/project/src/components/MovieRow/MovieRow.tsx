import React, { useRef, useState } from 'react';
import { ChevronLeft, ChevronRight, Play, Plus, Check, ThumbsUp, ChevronDown, Star } from 'lucide-react';
import { Movie } from '../../data/movies';
import { useApp } from '../../context/AppContext';

interface MovieRowProps {
  title: string;
  movies: Movie[];
  isTop10?: boolean;
}

const MovieRow: React.FC<MovieRowProps> = ({ title, movies, isTop10 = false }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [hoveredMovie, setHoveredMovie] = useState<string | null>(null);
  const { setSelectedMovie, setShowTrailer, addToMyList, removeFromMyList, isInMyList } = useApp();

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const scrollAmount = window.innerWidth < 768 ? 300 : 400;
      scrollRef.current.scrollBy({
        left: direction === 'left' ? -scrollAmount : scrollAmount,
        behavior: 'smooth'
      });
    }
  };

  const handleMovieClick = (movie: Movie) => {
    setSelectedMovie(movie);
    setShowTrailer(true);
  };

  const handleMyList = (e: React.MouseEvent, movie: Movie) => {
    e.stopPropagation();
    if (isInMyList(movie.id)) {
      removeFromMyList(movie.id);
    } else {
      addToMyList(movie);
    }
  };

  return (
    <div className="relative mb-8 sm:mb-10 lg:mb-12 group">
      <h2 className="text-white text-xl sm:text-2xl lg:text-3xl font-bold mb-4 sm:mb-6 px-4 sm:px-6 lg:px-12 text-shadow">
        {title}
      </h2>
      
      <div className="relative">
        {/* Left Arrow */}
        <button
          onClick={() => scroll('left')}
          className="absolute left-1 sm:left-2 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-70 text-white p-2 sm:p-3 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-opacity-90 hover:scale-110 shadow-2xl"
        >
          <ChevronLeft size={20} className="sm:w-7 sm:h-7" />
        </button>

        {/* Right Arrow */}
        <button
          onClick={() => scroll('right')}
          className="absolute right-1 sm:right-2 top-1/2 transform -translate-y-1/2 z-20 bg-black bg-opacity-70 text-white p-2 sm:p-3 rounded-full opacity-0 group-hover:opacity-100 transition-all duration-300 hover:bg-opacity-90 hover:scale-110 shadow-2xl"
        >
          <ChevronRight size={20} className="sm:w-7 sm:h-7" />
        </button>

        {/* Movies Container */}
        <div
          ref={scrollRef}
          className={`flex ${isTop10 ? 'space-x-4 sm:space-x-6 lg:space-x-8' : 'space-x-2 sm:space-x-3 lg:space-x-4'} overflow-x-auto scrollbar-hide px-4 sm:px-6 lg:px-12 pb-4 sm:pb-6`}
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {movies.map((movie, index) => (
            <div
              key={movie.id}
              className={`relative ${isTop10 ? 'min-w-[160px] sm:min-w-[200px] md:min-w-[240px] lg:min-w-[300px] xl:min-w-[340px]' : 'min-w-[140px] sm:min-w-[180px] md:min-w-[220px] lg:min-w-[280px] xl:min-w-[320px]'} group/movie cursor-pointer`}
              onMouseEnter={() => setHoveredMovie(movie.id)}
              onMouseLeave={() => setHoveredMovie(null)}
              onClick={() => handleMovieClick(movie)}
            >
              <div className="relative transform transition-all duration-500 group-hover/movie:scale-105 sm:group-hover/movie:scale-110 group-hover/movie:z-30">
                {/* Top 10 Badge */}
                {isTop10 && (
                  <div className="absolute -left-3 sm:-left-4 lg:-left-6 top-6 sm:top-8 lg:top-10 z-20 bg-gradient-to-r from-red-600 to-red-700 text-white px-3 py-2 sm:px-4 sm:py-3 lg:px-6 lg:py-4 text-lg sm:text-xl lg:text-2xl xl:text-3xl font-black rounded-r-lg shadow-2xl border-l-4 border-yellow-400">
                    #{index + 1}
                  </div>
                )}

                {/* Movie Poster */}
                <div className="relative overflow-hidden rounded-lg shadow-2xl">
                  <img
                    src={movie.poster}
                    alt={movie.title}
                    className={`w-full ${isTop10 ? 'h-[240px] sm:h-[300px] md:h-[360px] lg:h-[450px] xl:h-[510px]' : 'h-[200px] sm:h-[270px] md:h-[330px] lg:h-[400px] xl:h-[480px]'} object-cover transition-all duration-500`}
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                  
                  {/* Netflix Original Badge */}
                  {movie.isNetflixOriginal && (
                    <div className="absolute top-3 sm:top-4 lg:top-6 left-3 sm:left-4 lg:left-6 bg-red-600 text-white px-2 py-1 sm:px-3 sm:py-2 lg:px-4 lg:py-2 text-xs sm:text-sm lg:text-base font-bold rounded shadow-lg">
                      NETFLIX
                    </div>
                  )}

                  {/* Rating Badge */}
                  <div className="absolute top-3 sm:top-4 lg:top-6 right-3 sm:right-4 lg:right-6 bg-black bg-opacity-80 backdrop-blur-sm text-white px-2 py-1 sm:px-3 sm:py-2 lg:px-4 lg:py-2 rounded-lg flex items-center space-x-1 sm:space-x-2">
                    <Star size={12} className="sm:w-4 sm:h-4 lg:w-5 lg:h-5 text-yellow-400" fill="currentColor" />
                    <span className="text-xs sm:text-sm lg:text-base font-bold">{movie.rating}</span>
                  </div>

                  {/* Movie Title Overlay */}
                  <div className={`absolute bottom-0 left-0 right-0 p-3 sm:p-4 lg:p-6 ${isTop10 ? 'pb-6 sm:pb-8 lg:pb-10' : ''}`}>
                    <h3 className="text-white font-bold text-sm sm:text-base lg:text-lg xl:text-xl mb-2 sm:mb-3 text-shadow line-clamp-2">
                      {movie.title}
                    </h3>
                    <div className="flex items-center space-x-2 sm:space-x-3 text-xs sm:text-sm lg:text-base text-gray-300 mb-3 sm:mb-4">
                      <span className="text-green-400 font-bold bg-green-400 bg-opacity-20 px-2 py-1 sm:px-3 sm:py-1 rounded">
                        {Math.round(movie.rating * 10)}%
                      </span>
                      <span className="border border-gray-400 px-2 py-1 sm:px-3 sm:py-1 rounded">
                        {movie.maturityRating}
                      </span>
                      <span>{movie.year}</span>
                    </div>
                  </div>
                </div>

                {/* Hover Overlay */}
                {hoveredMovie === movie.id && (
                  <div className={`absolute inset-0 bg-gradient-to-t from-black via-black/80 to-black/40 rounded-lg flex flex-col justify-end p-4 sm:p-6 lg:p-8 transition-all duration-500 backdrop-blur-sm ${isTop10 ? 'pb-8 sm:pb-10 lg:pb-12' : ''}`}>
                    <div className="w-full space-y-3 sm:space-y-4 lg:space-y-6">
                      <h3 className="text-white font-bold text-sm sm:text-base lg:text-xl xl:text-2xl mb-2 sm:mb-3 text-shadow">{movie.title}</h3>
                      
                      <div className="flex flex-wrap items-center gap-2 sm:gap-3 lg:gap-4 mb-3 sm:mb-4">
                        <span className="text-green-400 font-bold text-xs sm:text-sm lg:text-base bg-green-400 bg-opacity-20 px-2 py-1 sm:px-3 sm:py-1 rounded">
                          {Math.round(movie.rating * 10)}% Match
                        </span>
                        <span className="border border-gray-400 px-2 py-1 sm:px-3 sm:py-1 text-xs sm:text-sm text-white rounded">
                          {movie.maturityRating}
                        </span>
                        <span className="text-gray-300 text-xs sm:text-sm lg:text-base">{movie.year}</span>
                      </div>

                      <p className="text-gray-300 text-xs sm:text-sm lg:text-base line-clamp-2 mb-4 sm:mb-6">
                        {movie.description.substring(0, 100)}...
                      </p>

                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 sm:space-x-3">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleMovieClick(movie);
                            }}
                            className="bg-white text-black p-2 sm:p-3 lg:p-4 rounded-full hover:bg-gray-200 transition-all duration-300 hover:scale-110 shadow-lg"
                          >
                            <Play size={16} className="sm:w-5 sm:h-5 lg:w-6 lg:h-6" fill="black" />
                          </button>
                          <button
                            onClick={(e) => handleMyList(e, movie)}
                            className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 lg:p-4 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg"
                          >
                            {isInMyList(movie.id) ? <Check size={16} className="sm:w-5 sm:h-5 lg:w-6 lg:h-6" /> : <Plus size={16} className="sm:w-5 sm:h-5 lg:w-6 lg:h-6" />}
                          </button>
                          <button className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 lg:p-4 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg">
                            <ThumbsUp size={16} className="sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                          </button>
                        </div>
                        <button className="bg-gray-800 bg-opacity-80 backdrop-blur-sm text-white p-2 sm:p-3 lg:p-4 rounded-full hover:bg-gray-700 transition-all duration-300 hover:scale-110 shadow-lg">
                          <ChevronDown size={16} className="sm:w-5 sm:h-5 lg:w-6 lg:h-6" />
                        </button>
                      </div>

                      {/* Genres */}
                      <div className="flex flex-wrap gap-1 sm:gap-2 mt-3 sm:mt-4">
                        {movie.genre.slice(0, 3).map((genre, idx) => (
                          <span key={idx} className="bg-red-600 bg-opacity-80 text-white px-2 py-1 sm:px-3 sm:py-1 rounded text-xs sm:text-sm font-semibold">
                            {genre}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MovieRow;