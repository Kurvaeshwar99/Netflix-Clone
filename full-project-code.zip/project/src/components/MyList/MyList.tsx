import React from 'react';
import { useApp } from '../../context/AppContext';
import { Trash2, Play, Star, Calendar } from 'lucide-react';

const MyList: React.FC = () => {
  const { myList, removeFromMyList, setSelectedMovie, setShowTrailer } = useApp();

  const handlePlay = (movie: any) => {
    setSelectedMovie(movie);
    setShowTrailer(true);
  };

  const handleRemove = (movieId: string) => {
    removeFromMyList(movieId);
  };

  return (
    <div className="bg-black min-h-screen pt-20 sm:pt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-white text-3xl sm:text-4xl lg:text-5xl font-black mb-8 sm:mb-12 text-shadow">My List</h1>
        
        {myList.length === 0 ? (
          <div className="text-center py-16 sm:py-20">
            <div className="bg-gray-900 bg-opacity-50 backdrop-blur-sm rounded-2xl p-8 sm:p-12 max-w-md mx-auto border border-gray-800">
              <h2 className="text-white text-2xl sm:text-3xl font-bold mb-4 sm:mb-6">Your list is empty</h2>
              <p className="text-gray-400 text-base sm:text-lg">Add movies and TV shows to your list to watch them later</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4 lg:gap-6">
            {myList.map((movie) => (
              <div key={movie.id} className="relative group cursor-pointer">
                <div className="relative overflow-hidden rounded-xl shadow-2xl transform transition-all duration-500 group-hover:scale-105">
                  <img
                    src={movie.poster}
                    alt={movie.title}
                    className="w-full h-48 sm:h-64 lg:h-80 object-cover"
                  />
                  
                  {/* Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-60"></div>
                  
                  {/* Rating Badge */}
                  <div className="absolute top-2 sm:top-4 right-2 sm:right-4 bg-black bg-opacity-80 backdrop-blur-sm text-white px-2 py-1 sm:px-3 sm:py-1 rounded-lg flex items-center space-x-1">
                    <Star size={12} className="sm:w-4 sm:h-4 text-yellow-400" fill="currentColor" />
                    <span className="text-xs sm:text-sm font-bold">{movie.rating}</span>
                  </div>

                  {/* Netflix Original Badge */}
                  {movie.isNetflixOriginal && (
                    <div className="absolute top-2 sm:top-4 left-2 sm:left-4 bg-red-600 text-white px-2 py-1 sm:px-3 sm:py-1 text-xs font-bold rounded shadow-lg">
                      NETFLIX
                    </div>
                  )}
                  
                  {/* Hover Overlay */}
                  <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-80 transition-all duration-500 flex items-center justify-center">
                    <div className="opacity-0 group-hover:opacity-100 transition-all duration-500 flex space-x-2 sm:space-x-3">
                      <button
                        onClick={() => handlePlay(movie)}
                        className="bg-white text-black p-3 sm:p-4 rounded-full hover:bg-gray-200 transition-all duration-300 hover:scale-110 shadow-2xl"
                      >
                        <Play size={16} className="sm:w-5 sm:h-5" fill="black" />
                      </button>
                      <button
                        onClick={() => handleRemove(movie.id)}
                        className="bg-red-600 text-white p-3 sm:p-4 rounded-full hover:bg-red-700 transition-all duration-300 hover:scale-110 shadow-2xl"
                      >
                        <Trash2 size={16} className="sm:w-5 sm:h-5" />
                      </button>
                    </div>
                  </div>
                </div>
                
                <div className="mt-3 sm:mt-4 space-y-1 sm:space-y-2">
                  <h3 className="text-white font-bold text-sm sm:text-base lg:text-lg truncate">{movie.title}</h3>
                  <div className="flex flex-wrap items-center gap-2 sm:gap-3 text-xs sm:text-sm text-gray-400">
                    <div className="flex items-center space-x-1">
                      <Calendar size={12} className="sm:w-4 sm:h-4" />
                      <span>{movie.year}</span>
                    </div>
                    <span className="border border-gray-600 px-1 py-0.5 sm:px-2 sm:py-1 text-xs rounded">
                      {movie.maturityRating}
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {movie.genre.slice(0, 2).map((genre, index) => (
                      <span key={index} className="bg-red-600 bg-opacity-80 text-white px-1 py-0.5 sm:px-2 sm:py-1 rounded text-xs font-semibold">
                        {genre}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyList;