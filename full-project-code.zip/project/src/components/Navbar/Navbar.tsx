import React, { useState } from 'react';
import { Search, Bell, ChevronDown, X, User, LogOut } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';

const Navbar: React.FC = () => {
  const [showSearch, setShowSearch] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const { user, logout } = useAuth();
  const { setCurrentView, currentView } = useApp();

  const handleLogout = () => {
    logout();
    setShowUserMenu(false);
  };

  const clearSearch = () => {
    setSearchTerm('');
    setShowSearch(false);
  };

  const navItems = [
    { name: 'Home', view: 'home' as const },
    { name: 'TV Shows', view: 'tv-shows' as const },
    { name: 'Movies', view: 'movies' as const },
    { name: 'My List', view: 'my-list' as const }
  ];

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-black bg-opacity-95 backdrop-blur-md transition-all duration-300 border-b border-gray-800 border-opacity-30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo */}
          <div className="flex items-center space-x-4 sm:space-x-8">
            <h1 className="text-red-600 text-2xl sm:text-3xl font-black tracking-tight">NETFLIX</h1>
            
            {/* Navigation Links - Hidden on mobile */}
            <div className="hidden md:flex space-x-6 lg:space-x-8">
              {navItems.map((item) => (
                <button
                  key={item.name}
                  onClick={() => setCurrentView(item.view)}
                  className={`text-sm font-semibold transition-all duration-300 hover:text-white relative ${
                    currentView === item.view ? 'text-white' : 'text-gray-300'
                  }`}
                >
                  {item.name}
                  {currentView === item.view && (
                    <div className="absolute -bottom-1 left-0 right-0 h-0.5 bg-red-600 rounded-full"></div>
                  )}
                </button>
              ))}
            </div>

            {/* Mobile Navigation Menu */}
            <div className="md:hidden">
              <select
                value={currentView}
                onChange={(e) => setCurrentView(e.target.value as any)}
                className="bg-transparent text-white text-sm font-semibold border border-gray-600 rounded px-3 py-1 focus:outline-none focus:border-red-500"
              >
                {navItems.map((item) => (
                  <option key={item.name} value={item.view} className="bg-black text-white">
                    {item.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Right Side */}
          <div className="flex items-center space-x-3 sm:space-x-4 lg:space-x-6">
            {/* Search */}
            <div className="relative">
              {showSearch ? (
                <div className="flex items-center bg-black bg-opacity-80 backdrop-blur-sm border border-gray-600 rounded-lg overflow-hidden">
                  <Search size={16} className="sm:w-5 sm:h-5 text-gray-400 mx-2 sm:mx-3" />
                  <input
                    type="text"
                    placeholder="Search..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="bg-transparent text-white placeholder-gray-400 py-2 sm:py-3 pr-2 sm:pr-3 pl-1 focus:outline-none w-48 sm:w-64 lg:w-80 text-sm sm:text-base"
                    autoFocus
                  />
                  <button
                    onClick={clearSearch}
                    className="text-gray-400 hover:text-white mx-2 sm:mx-3 transition-colors"
                  >
                    <X size={16} className="sm:w-5 sm:h-5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => setShowSearch(true)}
                  className="text-white hover:text-gray-300 transition-all duration-300 p-2 rounded-lg hover:bg-gray-800 hover:bg-opacity-50"
                >
                  <Search size={18} className="sm:w-6 sm:h-6" />
                </button>
              )}
            </div>

            {/* Notifications */}
            <button className="text-white hover:text-gray-300 transition-all duration-300 p-2 rounded-lg hover:bg-gray-800 hover:bg-opacity-50 relative">
              <Bell size={18} className="sm:w-6 sm:h-6" />
              <div className="absolute top-1 right-1 w-2 h-2 bg-red-600 rounded-full"></div>
            </button>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-2 sm:space-x-3 text-white hover:text-gray-300 transition-all duration-300 p-1 sm:p-2 rounded-lg hover:bg-gray-800 hover:bg-opacity-50"
              >
                <img
                  src={user?.avatar}
                  alt="Profile"
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-lg object-cover border-2 border-gray-600"
                />
                <ChevronDown size={14} className={`sm:w-4 sm:h-4 transition-transform duration-300 ${showUserMenu ? 'rotate-180' : ''}`} />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 mt-2 w-64 sm:w-72 bg-black bg-opacity-95 backdrop-blur-md rounded-xl py-4 shadow-2xl border border-gray-800 border-opacity-50">
                  <div className="px-4 sm:px-6 py-4 border-b border-gray-800 border-opacity-50">
                    <div className="flex items-center space-x-3 sm:space-x-4">
                      <img
                        src={user?.avatar}
                        alt="Profile"
                        className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg object-cover border-2 border-gray-600"
                      />
                      <div>
                        <p className="text-white text-base sm:text-lg font-bold">{user?.name}</p>
                        <p className="text-gray-400 text-xs sm:text-sm">{user?.email}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="px-2 py-2">
                    <button className="w-full flex items-center space-x-3 px-3 sm:px-4 py-3 text-white hover:bg-gray-800 hover:bg-opacity-50 transition-all duration-300 rounded-lg">
                      <User size={16} className="sm:w-5 sm:h-5" />
                      <span className="text-sm sm:text-base">Manage Profiles</span>
                    </button>
                    
                    <button
                      onClick={handleLogout}
                      className="w-full flex items-center space-x-3 px-3 sm:px-4 py-3 text-white hover:bg-red-600 hover:bg-opacity-20 transition-all duration-300 rounded-lg group"
                    >
                      <LogOut size={16} className="sm:w-5 sm:h-5 group-hover:text-red-400" />
                      <span className="group-hover:text-red-400 text-sm sm:text-base">Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;