import React from 'react';
import MovieRow from '../MovieRow/MovieRow';
import { tvShows, dramaMovies, comedyMovies } from '../../data/movies';

const TVShows: React.FC = () => {
  return (
    <div className="bg-black min-h-screen pt-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-white text-4xl font-bold mb-8">TV Shows</h1>
        
        <div className="space-y-8">
          <MovieRow title="Popular TV Shows" movies={tvShows} />
          <MovieRow title="Drama Series" movies={dramaMovies} />
          <MovieRow title="Comedy Series" movies={comedyMovies} />
        </div>
      </div>
    </div>
  );
};

export default TVShows;