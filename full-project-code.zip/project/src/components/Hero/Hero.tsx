import React from 'react';
import { Play, Info, Plus, Check, Star, Award } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { movies } from '../../data/movies';

const Hero: React.FC = () => {
  const { setSelectedMovie, setShowTrailer, addToMyList, removeFromMyList, isInMyList } = useApp();
  const featuredMovie = movies[0]; // Use first movie as featured

  const handlePlay = () => {
    setSelectedMovie(featuredMovie);
    setShowTrailer(true);
  };

  const handleMyList = () => {
    if (isInMyList(featuredMovie.id)) {
      removeFromMyList(featuredMovie.id);
    } else {
      addToMyList(featuredMovie);
    }
  };

  const inMyList = isInMyList(featuredMovie.id);

  return (
    <div className="relative h-screen overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <img
          src={featuredMovie.backdrop}
          alt={featuredMovie.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/70 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-transparent"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl space-y-4 sm:space-y-6 lg:space-y-8">
          {/* Netflix Original Badge */}
          {featuredMovie.isNetflixOriginal && (
            <div className="mb-4 sm:mb-6">
              <span className="bg-red-600 text-white px-3 py-1 sm:px-4 sm:py-2 text-xs sm:text-sm font-bold rounded shadow-lg">
                NETFLIX ORIGINAL
              </span>
            </div>
          )}

          {/* Title */}
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-black text-white mb-4 sm:mb-6 leading-tight text-shadow">
            {featuredMovie.title}
          </h1>

          {/* Movie Info */}
          <div className="flex flex-wrap items-center gap-3 sm:gap-4 lg:gap-6 mb-4 sm:mb-6 text-white">
            <div className="flex items-center space-x-2">
              <Star className="text-yellow-400" size={20} fill="currentColor" />
              <span className="text-yellow-400 font-bold text-sm sm:text-base lg:text-lg">
                {featuredMovie.rating}/10
              </span>
            </div>
            <span className="text-green-400 font-bold text-sm sm:text-base lg:text-lg bg-green-400 bg-opacity-20 px-2 py-1 sm:px-3 sm:py-1 rounded">
              {Math.round(featuredMovie.rating * 10)}% Match
            </span>
            <span className="border-2 border-gray-400 px-2 py-1 sm:px-3 sm:py-1 text-xs sm:text-sm font-semibold rounded">
              {featuredMovie.maturityRating}
            </span>
            <span className="text-sm sm:text-base lg:text-lg font-semibold">{featuredMovie.year}</span>
            <span className="text-sm sm:text-base lg:text-lg">{featuredMovie.duration}</span>
          </div>

          {/* Awards */}
          {featuredMovie.awards && (
            <div className="flex items-center space-x-2 mb-3 sm:mb-4">
              <Award className="text-yellow-400" size={16} sm:size={20} />
              <span className="text-yellow-400 font-semibold text-sm sm:text-base">{featuredMovie.awards}</span>
            </div>
          )}

          {/* Genres */}
          <div className="flex flex-wrap gap-2 mb-4 sm:mb-6">
            {featuredMovie.genre.map((genre, index) => (
              <span key={index} className="bg-red-600 bg-opacity-80 text-white px-2 py-1 sm:px-3 sm:py-1 rounded-full text-xs sm:text-sm font-semibold">
                {genre}
              </span>
            ))}
          </div>

          {/* Description */}
          <p className="text-base sm:text-lg lg:text-xl text-gray-200 mb-6 sm:mb-8 lg:mb-10 leading-relaxed text-shadow max-w-2xl">
            {featuredMovie.description}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
            <button
              onClick={handlePlay}
              className="flex items-center justify-center space-x-2 sm:space-x-3 bg-white text-black px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-4 rounded-lg font-bold text-sm sm:text-base lg:text-lg hover:bg-gray-200 transition-all duration-300 hover:scale-105 shadow-2xl"
            >
              <Play size={20} fill="black" />
              <span>Play</span>
            </button>
            
            <button
              onClick={handleMyList}
              className="flex items-center justify-center space-x-2 sm:space-x-3 bg-gray-600 bg-opacity-80 backdrop-blur-sm text-white px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-4 rounded-lg font-bold text-sm sm:text-base lg:text-lg hover:bg-gray-500 transition-all duration-300 hover:scale-105 shadow-2xl"
            >
              {inMyList ? <Check size={20} /> : <Plus size={20} />}
              <span className="hidden sm:inline">{inMyList ? 'Remove from List' : 'My List'}</span>
              <span className="sm:hidden">{inMyList ? 'Remove' : 'Add'}</span>
            </button>
            
            <button 
              onClick={handlePlay}
              className="flex items-center justify-center space-x-2 sm:space-x-3 bg-gray-600 bg-opacity-80 backdrop-blur-sm text-white px-6 py-3 sm:px-8 sm:py-4 lg:px-10 lg:py-4 rounded-lg font-bold text-sm sm:text-base lg:text-lg hover:bg-gray-500 transition-all duration-300 hover:scale-105 shadow-2xl"
            >
              <Info size={20} />
              <span className="hidden sm:inline">More Info</span>
              <span className="sm:hidden">Info</span>
            </button>
          </div>

          {/* Additional Info */}
          <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-6 text-gray-300 text-sm sm:text-base">
            <span>Starring: {featuredMovie.cast?.slice(0, 2).join(', ')}</span>
            <span>Director: {featuredMovie.director}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;